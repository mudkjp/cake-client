package dev.mudkip.compresso.core.v1;

import com.luciad.imageio.webp.WebPWriteParam;

import javax.imageio.IIOImage;
import javax.imageio.ImageIO;
import javax.imageio.ImageWriteParam;
import javax.imageio.ImageWriter;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;

public final class Encoders {
    private static final Map<String, Boolean> INSTALLED = new ConcurrentHashMap<>();

    private Encoders() {

    }

    private enum Backend { PNG, IMAGEIO, EXTERNAL }

    public static ImageFormat resolveFormat(CompressionOptions options) {
        return Encoders.backend(options.format(), options) == null ? ImageFormat.PNG : options.format();
    }

    public static String encode(BufferedImage image, ImageFormat format, CompressionOptions options, Path target) throws IOException, InterruptedException {
        var backend = Encoders.backend(format, options);
        switch (backend == null ? Backend.PNG : backend) {
            case PNG -> Png.write(image, options.pngCompressionLevel(), target);
            case IMAGEIO -> Encoders.writeImageIo(image, format, options, target);
            case EXTERNAL -> Encoders.runExternal(image, format, options, target);
        }
        return backend == null ? "png" : backend.name().toLowerCase();
    }

    public static boolean isInstalled(String command) {
        return Encoders.INSTALLED.computeIfAbsent(command, Encoders::probe);
    }

    public static void clearCache() {
        Encoders.INSTALLED.clear();
    }

    private static Backend backend(ImageFormat format, CompressionOptions options) {
        if (Encoders.isExternalOnly(format)) {
            return Encoders.externalAvailable(options, format) ? Backend.EXTERNAL : null;
        }

        var preferExternal = options.useExternalEncoders() && options.preferExternalWhenAvailable();

        if (preferExternal && Encoders.externalAvailable(options, format)) {
            return Backend.EXTERNAL;
        }

        if (Encoders.internalAvailable(format)) {
            return format == ImageFormat.PNG ? Backend.PNG : Backend.IMAGEIO;
        }

        if (Encoders.externalAvailable(options, format)) {
            return Backend.EXTERNAL;
        }

        return null;
    }

    private static boolean isExternalOnly(ImageFormat format) {
        return format == ImageFormat.AVIF || format == ImageFormat.JPEGXL;
    }

    private static boolean lossless(ImageFormat format, CompressionOptions options) {
        return format.resolveMode(options.compressionMode()) == CompressionMode.LOSSLESS;
    }

    private static boolean internalAvailable(ImageFormat format) {
        return switch (format) {
            case PNG -> true;
            case JPEG -> Encoders.hasImageIoWriter("jpeg");
            case WEBP -> Encoders.hasImageIoWriter("webp");
            case AVIF, JPEGXL -> false;
        };
    }

    private static boolean externalAvailable(CompressionOptions options, ImageFormat format) {
        if (!Encoders.isExternalOnly(format) && !options.useExternalEncoders()) {
            return false;
        }

        return Encoders.isInstalled(Encoders.commandFor(options, format));
    }

    private static void writeImageIo(BufferedImage image, ImageFormat format, CompressionOptions options, Path target) throws IOException {
        var quality = options.quality() / 100.0F;

        if (format == ImageFormat.JPEG) {
            var writer = Encoders.firstImageIoWriter("jpeg");
            var param = writer.getDefaultWriteParam();
            param.setCompressionMode(ImageWriteParam.MODE_EXPLICIT);
            param.setCompressionQuality(quality);
            Encoders.write(writer, Encoders.toRgb(image), param, target);
        } else {
            var writer = Encoders.firstImageIoWriter("webp");
            var param = new WebPWriteParam(writer.getLocale());
            param.setCompressionMode(ImageWriteParam.MODE_EXPLICIT);
            var type = Encoders.lossless(format, options) ? WebPWriteParam.LOSSLESS_COMPRESSION : WebPWriteParam.LOSSY_COMPRESSION;
            param.setCompressionType(param.getCompressionTypes()[type]);
            param.setCompressionQuality(quality);
            param.setMethod(options.webpMethod());
            Encoders.write(writer, image, param, target);
        }
    }

    private static void write(ImageWriter writer, BufferedImage image, ImageWriteParam param, Path target) throws IOException {
        try (var outputStream = Files.newOutputStream(target); var stream = ImageIO.createImageOutputStream(outputStream)) {
            writer.setOutput(stream);
            writer.write(null, new IIOImage(image, null, null), param);
        } finally {
            writer.dispose();
        }
    }

    private static BufferedImage toRgb(BufferedImage source) {
        if (source.getType() == BufferedImage.TYPE_INT_RGB) {
            return source;
        }

        var rgb = new BufferedImage(source.getWidth(), source.getHeight(), BufferedImage.TYPE_INT_RGB);
        var graphics = rgb.createGraphics();
        graphics.drawImage(source, 0, 0, null);
        graphics.dispose();
        return rgb;
    }

    private static boolean hasImageIoWriter(String formatName) {
        try {
            return ImageIO.getImageWritersByFormatName(formatName).hasNext();
        } catch (Throwable throwable) {
            return false;
        }
    }

    private static ImageWriter firstImageIoWriter(String formatName) throws IOException {
        var writers = ImageIO.getImageWritersByFormatName(formatName);

        if (!writers.hasNext()) {
            throw new IOException("No ImageIO writer registered for " + formatName);
        }

        return writers.next();
    }

    private static void runExternal(BufferedImage image, ImageFormat format, CompressionOptions options, Path target) throws IOException, InterruptedException {
        var temporaryPng = Files.createTempFile("compresso-", ".png");

        try {
            Png.write(image, 1, temporaryPng);
            var command = Encoders.buildCommand(format, options, temporaryPng, target);
            Encoders.runProcess(command);

            if (!Files.exists(target) || Files.size(target) == 0) {
                throw new IOException("External encoder produced no output: " + String.join(" ", command));
            }
        } finally {
            Files.deleteIfExists(temporaryPng);
        }
    }

    private static List<String> buildCommand(ImageFormat format, CompressionOptions options, Path source, Path target) {
        var lossless = Encoders.lossless(format, options);
        var command = new ArrayList<String>();

        switch (format) {
            case AVIF -> {
                command.add(options.avifEncoderPath());
                command.add("--speed");
                command.add(Integer.toString(options.avifSpeed()));

                if (lossless) {
                    command.add("--lossless");
                } else {
                    var quantizer = Math.round((100 - options.quality()) / 100.0F * 63);
                    command.add("--min");
                    command.add(Integer.toString(quantizer));
                    command.add("--max");
                    command.add(Integer.toString(quantizer));
                }

                command.add(source.toString());
                command.add(target.toString());
            }

            case WEBP -> {
                command.add(options.webpEncoderPath());

                if (lossless) {
                    command.add("-lossless");
                } else {
                    command.add("-q");
                    command.add(Integer.toString(options.quality()));
                }

                command.add("-m");
                command.add(Integer.toString(options.webpMethod()));
                command.add(source.toString());
                command.add("-o");
                command.add(target.toString());
            }

            case JPEGXL -> {
                command.add(options.jxlEncoderPath());
                command.add("-e");
                command.add(Integer.toString(options.jxlEffort()));

                if (lossless) {
                    command.add("-d");
                    command.add("0");
                } else {
                    command.add("-q");
                    command.add(Integer.toString(options.quality()));
                }

                command.add(source.toString());
                command.add(target.toString());
            }

            case PNG -> {
                command.add(options.pngOptimizerPath());
                command.add("-o");
                command.add(options.pngCompressionLevel() >= 9 ? "max" : Integer.toString(Math.min(options.pngCompressionLevel(), 6)));
                command.add("--strip");
                command.add("safe");
                command.add("--out");
                command.add(target.toString());
                command.add(source.toString());
            }

            case JPEG -> {
                command.add(options.jpegEncoderPath());
                command.add("-quality");
                command.add(Integer.toString(options.quality()));
                command.add("-outfile");
                command.add(target.toString());
                command.add(source.toString());
            }
        }

        return command;
    }

    private static void runProcess(List<String> command) throws IOException, InterruptedException {
        var process = new ProcessBuilder(command).redirectErrorStream(true).start();
        var output = process.getInputStream().readAllBytes();

        if (!process.waitFor(60, TimeUnit.SECONDS)) {
            process.destroyForcibly();
            throw new IOException("External encoder timed out: " + command.getFirst());
        }

        if (process.exitValue() != 0) {
            throw new IOException(command.getFirst() + " exited with " + process.exitValue() + ": " + new String(output).strip());
        }
    }

    private static String commandFor(CompressionOptions options, ImageFormat format) {
        return switch (format) {
            case AVIF -> options.avifEncoderPath();
            case WEBP -> options.webpEncoderPath();
            case PNG -> options.pngOptimizerPath();
            case JPEG -> options.jpegEncoderPath();
            case JPEGXL -> options.jxlEncoderPath();
        };
    }

    private static boolean probe(String command) {
        try {
            var process = new ProcessBuilder(command, "--version").redirectErrorStream(true).start();
            process.getInputStream().readAllBytes();
            process.waitFor(5, TimeUnit.SECONDS);
            process.destroyForcibly();
            return true;
        } catch (IOException notFound) {
            return false;
        } catch (InterruptedException interrupted) {
            Thread.currentThread().interrupt();
            return false;
        }
    }
}
