package dev.mudkip.compresso.core.v1;

public record CompressionOptions(
        ImageFormat format,
        CompressionMode compressionMode,
        int quality,
        boolean matchWindowResolution,
        int pngCompressionLevel,
        int webpMethod,
        int avifSpeed,
        int jxlEffort,
        boolean useExternalEncoders,
        boolean preferExternalWhenAvailable,
        String avifEncoderPath,
        String webpEncoderPath,
        String pngOptimizerPath,
        String jpegEncoderPath,
        String jxlEncoderPath
) {
    public CompressionOptions {
        avifEncoderPath = CompressionOptions.defaultIfBlank(avifEncoderPath, "avifenc");
        webpEncoderPath = CompressionOptions.defaultIfBlank(webpEncoderPath, "cwebp");
        pngOptimizerPath = CompressionOptions.defaultIfBlank(pngOptimizerPath, "oxipng");
        jpegEncoderPath = CompressionOptions.defaultIfBlank(jpegEncoderPath, "cjpeg");
        jxlEncoderPath = CompressionOptions.defaultIfBlank(jxlEncoderPath, "cjxl");
    }

    public CompressionMode effectiveMode() {
        return this.format.resolveMode(this.compressionMode);
    }

    public boolean isLossless() {
        return this.effectiveMode() == CompressionMode.LOSSLESS;
    }

    private static String defaultIfBlank(String value, String fallback) {
        return value == null || value.isBlank() ? fallback : value;
    }
}
