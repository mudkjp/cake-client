package dev.mudkip.compresso.core.v1;

import org.jspecify.annotations.Nullable;

import java.nio.file.Path;

public record SavedScreenshot(Path path, long bytes, String backend, @Nullable Throwable fallbackCause) {
}
