package dev.mudkip.compresso.core.v1;

public enum ImageFormat {
    PNG("png", "png", "PNG", true, false),
    JPEG("jpeg", "jpg", "JPEG", false, true),
    WEBP("webp", "webp", "WebP", true, true),
    AVIF("avif", "avif", "AVIF", true, true),
    JPEGXL("jpegxl", "jxl", "JPEG XL", true, true);

    private final String id;
    private final String extension;
    private final String displayName;
    private final boolean supportsLossless;
    private final boolean supportsLossy;

    ImageFormat(String id, String extension, String displayName, boolean supportsLossless, boolean supportsLossy) {
        this.id = id;
        this.extension = extension;
        this.displayName = displayName;
        this.supportsLossless = supportsLossless;
        this.supportsLossy = supportsLossy;
    }

    public String getId() {
        return this.id;
    }

    public String getExtension() {
        return this.extension;
    }

    public String getDisplayName() {
        return this.displayName;
    }

    public boolean supportsLossless() {
        return this.supportsLossless;
    }

    public boolean supportsLossy() {
        return this.supportsLossy;
    }

    public CompressionMode resolveMode(CompressionMode requested) {
        if (requested == CompressionMode.LOSSLESS && !this.supportsLossless) {
            return CompressionMode.LOSSY;
        }

        if (requested == CompressionMode.LOSSY && !this.supportsLossy) {
            return CompressionMode.LOSSLESS;
        }

        return requested;
    }
}
