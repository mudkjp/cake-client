package dev.mudkip.compresso.core.v1;

public enum CompressionMode {
    LOSSLESS("lossless"),
    LOSSY("lossy");

    private final String id;

    CompressionMode(String id) {
        this.id = id;
    }

    public String getId() {
        return this.id;
    }
}
