package dev.mudkip.compresso.core.v1;

import org.jspecify.annotations.Nullable;

import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

public final class ScreenshotWriter {
    private static final String SCREENSHOT_DIRECTORY = "screenshots";

    private ScreenshotWriter() {

    }

    public static SavedScreenshot write(BufferedImage source, Path gameDirectory, @Nullable String forceName,
            int screenWidth, int screenHeight, String timestamp, CompressionOptions options) throws IOException, InterruptedException {
        var image = options.matchWindowResolution() ? ScreenshotWriter.matchWindow(source, screenWidth, screenHeight) : source;
        var directory = gameDirectory.resolve(ScreenshotWriter.SCREENSHOT_DIRECTORY);
        Files.createDirectories(directory);
        var format = Encoders.resolveFormat(options);
        var target = ScreenshotWriter.uniqueFile(directory, forceName, timestamp, format);

        try {
            var backend = Encoders.encode(image, format, options, target);
            return new SavedScreenshot(target, Files.size(target), backend, null);
        } catch (Throwable encodeError) {
            Files.deleteIfExists(target);
            target = ScreenshotWriter.uniqueFile(directory, forceName, timestamp, ImageFormat.PNG);

            try {
                var backend = Encoders.encode(image, ImageFormat.PNG, options, target);
                return new SavedScreenshot(target, Files.size(target), backend + " (fallback)", encodeError);
            } catch (Throwable fallbackError) {
                fallbackError.addSuppressed(encodeError);
                throw ScreenshotWriter.rethrow(fallbackError);
            }
        }
    }

    private static BufferedImage matchWindow(BufferedImage image, int screenWidth, int screenHeight) {
        if (screenWidth <= 0 || screenHeight <= 0 || image.getWidth() <= screenWidth) {
            return image;
        }

        var scaled = new BufferedImage(screenWidth, screenHeight, BufferedImage.TYPE_INT_ARGB);
        var graphics = scaled.createGraphics();
        graphics.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BICUBIC);
        graphics.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
        graphics.drawImage(image, 0, 0, screenWidth, screenHeight, null);
        graphics.dispose();
        return scaled;
    }

    private static Path uniqueFile(Path directory, @Nullable String forceName, String timestamp, ImageFormat format) {
        var extension = format.getExtension();

        if (forceName != null) {
            return directory.resolve(ScreenshotWriter.stripExtension(forceName) + "." + extension);
        }

        var count = 1;

        while (true) {
            var suffix = count == 1 ? "" : "_" + count;
            var candidate = directory.resolve(timestamp + suffix + "." + extension);

            if (!Files.exists(candidate)) {
                return candidate;
            }

            count++;
        }
    }

    private static String stripExtension(String name) {
        var dot = name.lastIndexOf('.');
        return dot > 0 ? name.substring(0, dot) : name;
    }

    private static RuntimeException rethrow(Throwable throwable) throws IOException, InterruptedException {
        if (throwable instanceof IOException ioException) {
            throw ioException;
        }

        if (throwable instanceof InterruptedException interruptedException) {
            throw interruptedException;
        }

        if (throwable instanceof RuntimeException runtimeException) {
            throw runtimeException;
        }

        if (throwable instanceof Error error) {
            throw error;
        }

        throw new IOException(throwable);
    }
}
